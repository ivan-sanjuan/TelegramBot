


def symbol_handler(symbol):
    return symbol

def book_handler(book):
    return book
    
    
    